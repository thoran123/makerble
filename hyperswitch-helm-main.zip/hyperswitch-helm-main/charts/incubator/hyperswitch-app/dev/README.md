Development manifest, scripts,  helm values.yaml used to build this chart.

Have a look in ../Taskfile.yaml 