---
description: Install Hyperswitch on K8s using Helm
---

# Deploy on Kubernetes using Helm

Follow the docs here to install hyperswitch services 
https://github.com/juspay/hyperswitch-helm/tree/main/charts/incubator/hyperswitch-stack#readme
